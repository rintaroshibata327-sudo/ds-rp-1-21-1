Flan + Lootr 日本語化リソースパック

対象:
- Minecraft 1.21.1
- Flan 1.21.1-1.12.8 NeoForge
- Lootr 1.21.1-1.11.38.124 NeoForge

導入方法:
1. このZIPを展開せず、そのままMinecraftの resourcepacks フォルダへ入れます。
2. ゲーム内の「設定」→「リソースパック」で有効化します。
3. 言語を「日本語」にします。

公開サーバーで全員へ適用する場合:
- 配布するModpackにこのリソースパックを同梱するか、
- server.properties の resource-pack 設定でサーバーリソースパックとして配布してください。

注意:
- コマンド構文（/flan ...、true/false/default など）は、実際に入力する文字列との混乱を避けるため原文を残しています。
- Lootrは元のja_jp.jsonを基礎に、英語のまま残っていた新規項目を補完しています。
